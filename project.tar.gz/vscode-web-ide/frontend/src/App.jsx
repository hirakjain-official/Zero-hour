import React, { useState, useEffect, useRef, useCallback } from 'react';
import ActivityBar from './components/ActivityBar';
import Sidebar from './components/Sidebar';
import TabBar from './components/TabBar';
import Editor from './components/Editor';
import Terminal from './components/Terminal';
import StatusBar from './components/StatusBar';
import CommandPalette from './components/CommandPalette';
import Preview from './components/Preview';
import AiChat from './components/AiChat';
import { Smartphone, Sparkles, PanelLeft, PanelBottom, ChevronRight, ChevronLeft } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001';

function useNotification() {
  const [notification, setNotification] = useState(null);
  const show = (msg, type = 'info') => {
    setNotification({ msg, type, id: Date.now() });
    setTimeout(() => setNotification(null), 3000);
  };
  return [notification, show];
}

export default function App() {
  const [activePanel, setActivePanel] = useState('explorer');
  const [tabs, setTabs] = useState([]);
  const [activeTab, setActiveTab] = useState(null);
  const [fileTree, setFileTree] = useState(null);

  // Panel visibility (all collapsible)
  const [showSidebar, setShowSidebar] = useState(true);
  const [showTerminal, setShowTerminal] = useState(true);
  const [showPreview, setShowPreview] = useState(true);
  const [showAI, setShowAI] = useState(true);

  const [activeTerminalTab, setActiveTerminalTab] = useState('output');
  const [terminalOutput, setTerminalOutput] = useState([
    { type: 'info', text: '✅  VS Code Web IDE is ready! Click ▶ Run to execute files.' },
    { type: 'info', text: `📁  Workspace: ${API}/api/files` },
    { type: 'info', text: '──────────────────────────────────────────────────────────' },
  ]);
  const [showPalette, setShowPalette] = useState(false);
  const [notification, showNotification] = useNotification();
  const [panelHeight, setPanelHeight] = useState(220);
  const [isRunning, setIsRunning] = useState(false);
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [currentLang, setCurrentLang] = useState('plaintext');

  const loadTree = useCallback(async () => {
    try {
      const res = await fetch(`${API}/api/files/tree`);
      const data = await res.json();
      setFileTree(data);
    } catch (e) {
      console.error('Failed to load file tree', e);
    }
  }, []);

  useEffect(() => { loadTree(); }, [loadTree]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'P') {
        e.preventDefault(); setShowPalette(true);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault(); setShowPalette(true);
      }
      if (e.key === 'Escape') setShowPalette(false);
      if ((e.ctrlKey || e.metaKey) && e.key === '`') {
        e.preventDefault(); setShowTerminal(p => !p);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
        e.preventDefault(); setShowSidebar(p => !p);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'w') {
        e.preventDefault();
        if (activeTab) closeTab(activeTab);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [activeTab]);

  const openFile = async (filePath) => {
    const existing = tabs.find(t => t.path === filePath);
    if (existing) { setActiveTab(existing.id); return; }
    try {
      const res = await fetch(`${API}/api/files/read?path=${encodeURIComponent(filePath)}`);
      const data = await res.json();
      const tab = {
        id: Date.now().toString(),
        path: filePath,
        name: filePath.split('/').pop() || filePath.split('\\').pop() || filePath,
        content: data.content,
        savedContent: data.content,
        modified: false
      };
      setTabs(prev => [...prev, tab]);
      setActiveTab(tab.id);
    } catch (e) {
      showNotification('Failed to open file: ' + e.message, 'error');
    }
  };

  const saveFile = async (tabId, content) => {
    const tab = tabs.find(t => t.id === tabId);
    if (!tab) return;
    try {
      await fetch(`${API}/api/files/write`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: tab.path, content })
      });
      setTabs(prev => prev.map(t =>
        t.id === tabId ? { ...t, content, savedContent: content, modified: false } : t
      ));
      showNotification(`Saved ${tab.name}`, 'success');
    } catch (e) {
      showNotification('Save failed: ' + e.message, 'error');
    }
  };

  const closeTab = (tabId) => {
    const idx = tabs.findIndex(t => t.id === tabId);
    const newTabs = tabs.filter(t => t.id !== tabId);
    setTabs(newTabs);
    if (activeTab === tabId) {
      setActiveTab(newTabs.length > 0 ? newTabs[Math.min(idx, newTabs.length - 1)].id : null);
    }
  };

  const updateTabContent = (tabId, content) => {
    setTabs(prev => prev.map(t =>
      t.id === tabId ? { ...t, content, modified: content !== t.savedContent } : t
    ));
  };

  const runCode = async () => {
    const tab = tabs.find(t => t.id === activeTab);
    if (!tab) return;
    setIsRunning(true);
    setShowTerminal(true);
    setActiveTerminalTab('output');
    setTerminalOutput(prev => [
      ...prev,
      { type: 'info', text: `\n▶  Running: ${tab.name}` },
      { type: 'info', text: '──────────────────────────────────' }
    ]);

    try {
      const res = await fetch(`${API}/api/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: tab.path, code: tab.content, filename: tab.name })
      });
      const data = await res.json();
      if (data.stdout) data.stdout.split('\n').filter(Boolean).forEach(line =>
        setTerminalOutput(prev => [...prev, { type: 'stdout', text: line }])
      );
      if (data.stderr) data.stderr.split('\n').filter(Boolean).forEach(line =>
        setTerminalOutput(prev => [...prev, { type: 'stderr', text: line }])
      );
      setTerminalOutput(prev => [...prev, {
        type: data.exitCode === 0 ? 'success' : 'error',
        text: `\n[Process exited with code ${data.exitCode}]`
      }]);
    } catch (e) {
      setTerminalOutput(prev => [...prev, { type: 'error', text: 'Failed to execute: ' + e.message }]);
    }
    setIsRunning(false);
  };

  // Panel resize
  const startResize = (e) => {
    const startY = e.clientY;
    const startH = panelHeight;
    const onMove = (ev) => setPanelHeight(Math.max(80, Math.min(600, startH + (startY - ev.clientY))));
    const onUp = () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };

  const activeTabData = tabs.find(t => t.id === activeTab);

  const paletteCommands = [
    { label: 'View: Toggle Terminal', keybind: 'Ctrl+`', action: () => setShowTerminal(p => !p) },
    { label: 'View: Toggle Sidebar', keybind: 'Ctrl+B', action: () => setShowSidebar(p => !p) },
    { label: 'View: Toggle Preview', keybind: '', action: () => setShowPreview(p => !p) },
    { label: 'View: Toggle AI Assistant', keybind: '', action: () => setShowAI(p => !p) },
    { label: 'File: Save', keybind: 'Ctrl+S', action: () => activeTabData && saveFile(activeTab, activeTabData.content) },
    { label: 'File: Close Editor', keybind: 'Ctrl+W', action: () => activeTab && closeTab(activeTab) },
    { label: 'Run: Execute File', keybind: 'F5', action: runCode },
    { label: 'View: Explorer', action: () => { setActivePanel('explorer'); setShowSidebar(true); } },
    { label: 'View: Search', action: () => { setActivePanel('search'); setShowSidebar(true); } },
  ];

  return (
    <div className="ide-layout">
      {/* ── Title Bar ── */}
      <div className="titlebar">
        <div className="titlebar-dots">
          <div className="titlebar-dot red" />
          <div className="titlebar-dot yellow" />
          <div className="titlebar-dot green" />
        </div>
        <div className="titlebar-menubar">
          {['File', 'Edit', 'Selection', 'View', 'Go', 'Run', 'Terminal', 'Help'].map(m => (
            <div key={m} className="titlebar-menu-item">{m}</div>
          ))}
        </div>
        <div className="titlebar-title">
          {activeTabData
            ? `${activeTabData.name}${activeTabData.modified ? ' ●' : ''} — VS Code Web IDE`
            : 'VS Code Web IDE'}
        </div>

        {/* Quick panel toggles in title bar */}
        <div style={{ marginLeft: 'auto', display: 'flex', gap: '4px', alignItems: 'center', paddingRight: '8px' }}>
          <button
            onClick={() => setShowSidebar(p => !p)}
            title="Toggle Sidebar (Ctrl+B)"
            style={{
              background: showSidebar ? 'rgba(255,255,255,0.12)' : 'transparent',
              border: 'none', borderRadius: '4px', padding: '3px 6px', cursor: 'pointer',
              color: showSidebar ? '#fff' : '#888', transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px'
            }}>
            <PanelLeft size={13} />
          </button>
          <button
            onClick={() => setShowTerminal(p => !p)}
            title="Toggle Terminal (Ctrl+`)"
            style={{
              background: showTerminal ? 'rgba(255,255,255,0.12)' : 'transparent',
              border: 'none', borderRadius: '4px', padding: '3px 6px', cursor: 'pointer',
              color: showTerminal ? '#fff' : '#888', transition: 'all 0.15s', display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px'
            }}>
            <PanelBottom size={13} />
          </button>
          <div style={{ width: '1px', height: '16px', background: '#444', margin: '0 4px' }} />
          <button
            onClick={() => setShowPreview(p => !p)}
            title="Toggle Preview"
            style={{
              background: showPreview ? 'rgba(41,128,185,0.3)' : 'transparent',
              border: 'none', borderRadius: '4px', padding: '3px 7px', cursor: 'pointer',
              color: showPreview ? '#4fc3f7' : '#888', transition: 'all 0.15s',
              display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px'
            }}>
            <Smartphone size={13} />
            <span>Preview</span>
          </button>
          <button
            onClick={() => setShowAI(p => !p)}
            title="Toggle AI Assistant"
            style={{
              background: showAI ? 'rgba(198,120,221,0.25)' : 'transparent',
              border: 'none', borderRadius: '4px', padding: '3px 7px', cursor: 'pointer',
              color: showAI ? '#c678dd' : '#888', transition: 'all 0.15s',
              display: 'flex', alignItems: 'center', gap: '3px', fontSize: '11px'
            }}>
            <Sparkles size={13} />
            <span>AI</span>
          </button>
        </div>
      </div>

      {/* ── Main Body ── */}
      <div className="ide-body">
        {/* Activity Bar */}
        <ActivityBar activePanel={activePanel} setActivePanel={(p) => {
          if (p === activePanel && showSidebar) {
            setShowSidebar(false);
          } else {
            setActivePanel(p);
            setShowSidebar(true);
          }
        }} />

        {/* Sidebar (collapsible) */}
        {showSidebar && (
          <Sidebar
            activePanel={activePanel}
            fileTree={fileTree}
            activeFilePath={activeTabData?.path}
            onOpenFile={openFile}
            onRefreshTree={loadTree}
            showNotification={showNotification}
            API={API}
          />
        )}

        {/* Sidebar collapsed indicator */}
        {!showSidebar && (
          <div
            onClick={() => setShowSidebar(true)}
            style={{
              width: '4px', cursor: 'col-resize', background: 'transparent',
              transition: 'background 0.15s', flexShrink: 0
            }}
            onMouseEnter={e => { e.currentTarget.style.background = '#007acc'; }}
            onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
            title="Show Sidebar"
          />
        )}

        {/* ── Center: Editor + Terminal ── */}
        <div className="editor-area">
          <TabBar tabs={tabs} activeTab={activeTab} onSelect={setActiveTab} onClose={closeTab} />

          {activeTabData && (
            <div className="breadcrumb">
              <span>workspace</span>
              {activeTabData.path.split('/').map((seg, i, arr) => (
                <React.Fragment key={i}>
                  <span className="breadcrumb-sep">›</span>
                  <span style={{ color: i === arr.length - 1 ? '#ccc' : '#888' }}>{seg}</span>
                </React.Fragment>
              ))}
            </div>
          )}

          <Editor
            tab={activeTabData}
            onContentChange={updateTabContent}
            onSave={saveFile}
            onRun={runCode}
            isRunning={isRunning}
            onCursorChange={setCursorPos}
            onLanguageChange={setCurrentLang}
          />

          {showTerminal && (
            <Terminal
              height={panelHeight}
              output={terminalOutput}
              activeTab={activeTerminalTab}
              onTabChange={setActiveTerminalTab}
              onClose={() => setShowTerminal(false)}
              onClearOutput={() => setTerminalOutput([])}
              onResize={startResize}
              API={API}
            />
          )}
        </div>

        {/* ── Right: Preview + AI Chat ── */}
        <Preview
          previewUrl="http://localhost:5173"
          visible={showPreview}
          onToggle={() => setShowPreview(false)}
        />

        <AiChat
          API={API}
          currentTab={activeTabData}
          visible={showAI}
          onToggle={() => setShowAI(false)}
        />
      </div>

      {/* ── Status Bar ── */}
      <StatusBar
        language={currentLang}
        line={cursorPos.line}
        col={cursorPos.col}
        modified={activeTabData?.modified}
        fileName={activeTabData?.name}
        showPanel={showTerminal}
        onTogglePanel={() => setShowTerminal(p => !p)}
      />

      {/* Command Palette */}
      {showPalette && (
        <CommandPalette
          commands={paletteCommands}
          tabs={tabs}
          onOpenFile={openFile}
          onClose={() => setShowPalette(false)}
        />
      )}

      {/* Notification toast */}
      {notification && (
        <div className={`notification ${notification.type}`} key={notification.id}>
          {notification.type === 'success' && '✅'}
          {notification.type === 'error' && '❌'}
          {notification.type === 'info' && 'ℹ️'}
          {notification.msg}
        </div>
      )}
    </div>
  );
}
