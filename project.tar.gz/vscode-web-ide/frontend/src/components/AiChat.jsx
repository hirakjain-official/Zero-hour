import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Sparkles, RotateCcw, Copy, ChevronDown } from 'lucide-react';

const AVATARS = [
    { emoji: '🧑‍💻', name: 'Dev Bot' },
    { emoji: '🤖', name: 'AI Assistant' },
    { emoji: '👨‍🏫', name: 'Senior Engineer' },
];

const STARTERS = [
    'Explain this code',
    'Help me debug',
    'How do I optimize this?',
    'What does this error mean?',
    'Review my code',
];

function renderMessage(text) {
    // Simple markdown-style renderer
    const parts = text.split(/(```[\s\S]*?```)/g);
    return parts.map((part, i) => {
        if (part.startsWith('```')) {
            const code = part.replace(/```\w*\n?/, '').replace(/```$/, '');
            return (
                <pre key={i} style={{
                    background: '#1a1a1a', border: '1px solid #333', borderRadius: '6px',
                    padding: '10px 12px', margin: '8px 0', fontSize: '12px',
                    fontFamily: "'JetBrains Mono', monospace", overflowX: 'auto',
                    color: '#9cdcfe', lineHeight: '1.5'
                }}>
                    <code>{code.trim()}</code>
                </pre>
            );
        }
        // Render **bold** text
        const boldParts = part.split(/(\*\*[^*]+\*\*)/g);
        return (
            <span key={i}>
                {boldParts.map((bp, j) => {
                    if (bp.startsWith('**') && bp.endsWith('**')) {
                        return <strong key={j} style={{ color: '#e2e2e2' }}>{bp.slice(2, -2)}</strong>;
                    }
                    // Render `inline code`
                    const codeParts = bp.split(/(`[^`]+`)/g);
                    return codeParts.map((cp, k) => {
                        if (cp.startsWith('`') && cp.endsWith('`')) {
                            return (
                                <code key={k} style={{
                                    background: '#2d2d2d', border: '1px solid #3a3a3a',
                                    borderRadius: '3px', padding: '1px 5px', fontSize: '12px',
                                    fontFamily: "'JetBrains Mono', monospace", color: '#f48771'
                                }}>
                                    {cp.slice(1, -1)}
                                </code>
                            );
                        }
                        return <span key={k} style={{ whiteSpace: 'pre-wrap' }}>{cp}</span>;
                    });
                })}
            </span>
        );
    });
}

export default function AiChat({ API, currentTab, visible, onToggle }) {
    const [messages, setMessages] = useState([
        {
            role: 'assistant',
            text: "Hey! 👋 I'm your AI coding assistant. Open a file and ask me anything about it — debugging, explanations, optimizations, you name it!",
            ts: Date.now()
        }
    ]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [avatar] = useState(AVATARS[2]);
    const bottomRef = useRef(null);
    const inputRef = useRef(null);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, loading]);

    const send = async (msg) => {
        const text = (msg || input).trim();
        if (!text || loading) return;
        setInput('');

        const userMsg = { role: 'user', text, ts: Date.now() };
        setMessages(prev => [...prev, userMsg]);
        setLoading(true);

        try {
            const history = messages.slice(-6).map(m => ({
                role: m.role === 'user' ? 'user' : 'assistant',
                content: m.text
            }));

            const res = await fetch(`${API}/api/ai/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: text,
                    code: currentTab?.content?.slice(0, 3000),
                    language: currentTab?.name?.split('.').pop(),
                    history
                })
            });
            const data = await res.json();
            setMessages(prev => [...prev, { role: 'assistant', text: data.reply, ts: Date.now() }]);
        } catch (e) {
            setMessages(prev => [...prev, {
                role: 'assistant',
                text: `⚠️ Could not connect to AI backend. Make sure the server is running at ${API}`,
                ts: Date.now()
            }]);
        }
        setLoading(false);
    };

    const clear = () => {
        setMessages([{
            role: 'assistant',
            text: "Chat cleared! Ask me anything about your code.",
            ts: Date.now()
        }]);
    };

    if (!visible) return null;

    return (
        <div style={{
            width: '300px', flexShrink: 0, display: 'flex', flexDirection: 'column',
            background: '#1e1e1e', borderLeft: '1px solid #1a1a1a', overflow: 'hidden'
        }}>
            {/* Header */}
            <div style={{
                display: 'flex', alignItems: 'center', gap: '8px',
                padding: '0 12px', height: '35px', background: '#252526',
                borderBottom: '1px solid #1a1a1a', flexShrink: 0
            }}>
                <Sparkles size={14} color="#c678dd" />
                <span style={{ fontSize: '12px', fontWeight: 600, color: '#ccc', flex: 1 }}>AI ASSISTANT</span>
                <button
                    style={{ background: 'transparent', border: 'none', color: '#888', cursor: 'pointer', display: 'flex' }}
                    onClick={clear} title="Clear chat"
                >
                    <RotateCcw size={13} />
                </button>
                <button
                    style={{ background: 'transparent', border: 'none', color: '#888', cursor: 'pointer', display: 'flex' }}
                    onClick={onToggle} title="Hide AI panel"
                >
                    <ChevronDown size={14} />
                </button>
            </div>

            {/* Avatar */}
            <div style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center',
                padding: '16px 12px 8px', background: '#252526', borderBottom: '1px solid #333',
                flexShrink: 0
            }}>
                <div style={{
                    width: '56px', height: '56px', borderRadius: '50%', fontSize: '28px',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: 'linear-gradient(135deg, #1a1a2e, #16213e)',
                    border: '2px solid #c678dd', marginBottom: '6px',
                    boxShadow: '0 0 16px rgba(198, 120, 221, 0.3)'
                }}>
                    {avatar.emoji}
                </div>
                <div style={{ fontSize: '12px', color: '#e2e2e2', fontWeight: 600 }}>{avatar.name}</div>
                <div style={{
                    fontSize: '10px', color: '#89d185', marginTop: '2px',
                    display: 'flex', alignItems: 'center', gap: '4px'
                }}>
                    <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#89d185', display: 'inline-block' }} />
                    Online
                </div>
            </div>

            {/* Quick starters */}
            {messages.length <= 1 && (
                <div style={{ padding: '8px 10px', borderBottom: '1px solid #333', display: 'flex', flexWrap: 'wrap', gap: '5px', flexShrink: 0 }}>
                    {STARTERS.map(s => (
                        <button
                            key={s}
                            onClick={() => send(s)}
                            style={{
                                padding: '4px 8px', background: '#2d2d2d', border: '1px solid #444',
                                borderRadius: '12px', fontSize: '11px', color: '#aaa', cursor: 'pointer',
                                transition: 'all 0.15s', whiteSpace: 'nowrap'
                            }}
                            onMouseEnter={e => { e.target.style.background = '#3a3a3a'; e.target.style.color = '#fff'; }}
                            onMouseLeave={e => { e.target.style.background = '#2d2d2d'; e.target.style.color = '#aaa'; }}
                        >
                            {s}
                        </button>
                    ))}
                </div>
            )}

            {/* Messages */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '12px 10px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {messages.map((msg, i) => (
                    <div key={i} style={{
                        display: 'flex', flexDirection: 'column',
                        alignItems: msg.role === 'user' ? 'flex-end' : 'flex-start'
                    }}>
                        <div style={{
                            maxWidth: '90%',
                            padding: '8px 12px',
                            borderRadius: msg.role === 'user' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                            background: msg.role === 'user'
                                ? 'linear-gradient(135deg, #007acc, #005a9e)'
                                : '#2d2d2d',
                            color: '#e2e2e2',
                            fontSize: '12.5px',
                            lineHeight: '1.55',
                            border: msg.role === 'user' ? 'none' : '1px solid #3a3a3a',
                            boxShadow: '0 1px 4px rgba(0,0,0,0.3)'
                        }}>
                            {renderMessage(msg.text)}
                        </div>
                        <span style={{ fontSize: '10px', color: '#555', marginTop: '3px', padding: '0 4px' }}>
                            {new Date(msg.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                    </div>
                ))}

                {loading && (
                    <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                        <div style={{
                            padding: '10px 14px', borderRadius: '14px 14px 14px 4px',
                            background: '#2d2d2d', border: '1px solid #3a3a3a',
                            display: 'flex', gap: '5px', alignItems: 'center'
                        }}>
                            {[0, 1, 2].map(n => (
                                <div key={n} style={{
                                    width: '6px', height: '6px', borderRadius: '50%',
                                    background: '#c678dd',
                                    animation: `pulse 1.2s ease-in-out ${n * 0.2}s infinite`
                                }} />
                            ))}
                        </div>
                    </div>
                )}
                <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div style={{
                borderTop: '1px solid #1a1a1a', padding: '10px',
                display: 'flex', gap: '8px', alignItems: 'flex-end',
                background: '#252526', flexShrink: 0
            }}>
                <textarea
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => {
                        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
                    }}
                    placeholder="Ask about your code..."
                    rows={1}
                    style={{
                        flex: 1, background: '#3c3c3c', border: '1px solid #555',
                        borderRadius: '8px', padding: '7px 10px', color: '#e2e2e2',
                        fontSize: '12.5px', outline: 'none', resize: 'none',
                        fontFamily: 'Inter, sans-serif', lineHeight: '1.4',
                        maxHeight: '80px', scrollbarWidth: 'thin',
                        transition: 'border-color 0.15s'
                    }}
                    onFocus={e => { e.target.style.borderColor = '#c678dd'; }}
                    onBlur={e => { e.target.style.borderColor = '#555'; }}
                    onInput={e => {
                        e.target.style.height = 'auto';
                        e.target.style.height = Math.min(e.target.scrollHeight, 80) + 'px';
                    }}
                />
                <button
                    onClick={() => send()}
                    disabled={loading || !input.trim()}
                    style={{
                        width: '34px', height: '34px', borderRadius: '8px',
                        background: loading || !input.trim() ? '#2d2d2d' : 'linear-gradient(135deg, #c678dd, #9c59b6)',
                        border: 'none', cursor: loading || !input.trim() ? 'default' : 'pointer',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: '#fff', transition: 'all 0.2s', flexShrink: 0
                    }}
                >
                    {loading ? <Loader2 size={15} style={{ animation: 'spin 0.8s linear infinite' }} /> : <Send size={15} />}
                </button>
            </div>

            <style>{`
        @keyframes pulse {
          0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; }
          40% { transform: scale(1); opacity: 1; }
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
        </div>
    );
}
