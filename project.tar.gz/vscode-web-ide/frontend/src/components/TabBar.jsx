import React from 'react';
import { X } from 'lucide-react';

function getFileIcon(name) {
    const ext = name.split('.').pop()?.toLowerCase();
    const icons = {
        js: '📜', jsx: '⚛️', ts: '💙', tsx: '⚛️',
        py: '🐍', html: '🌐', css: '🎨', scss: '🎨',
        json: '📋', md: '📝', txt: '📄', sh: '⚙️',
    };
    return icons[ext] || '📄';
}

export default function TabBar({ tabs, activeTab, onSelect, onClose }) {
    return (
        <div className="tab-bar">
            {tabs.map(tab => (
                <div
                    key={tab.id}
                    className={`tab ${activeTab === tab.id ? 'active' : ''}`}
                    onClick={() => onSelect(tab.id)}
                >
                    <span style={{ fontSize: '13px', flexShrink: 0 }}>{getFileIcon(tab.name)}</span>
                    <span className="tab-name" title={tab.path}>
                        {tab.name}
                    </span>
                    {tab.modified && <span className="tab-dot" title="Unsaved changes" />}
                    <button
                        className="tab-close"
                        onClick={e => { e.stopPropagation(); onClose(tab.id); }}
                        title="Close"
                    >
                        <X size={13} />
                    </button>
                </div>
            ))}
        </div>
    );
}
