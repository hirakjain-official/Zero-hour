const express = require('express');
const router = express.Router();

// Simple rule-based AI code assistant
// Can be extended with real OpenAI/Gemini API

const SYSTEM_CONTEXT = `You are a senior software engineer AI assistant built into a VS Code-like web IDE. 
You help developers debug code, explain errors, suggest improvements, and answer coding questions.
Be concise, practical, and friendly. Format code examples with \`\`\` blocks.`;

// Smart mock responses for common coding questions
function getMockResponse(message, code, language) {
    const msg = message.toLowerCase();
    const lang = (language || '').toLowerCase();

    // Error detection patterns
    if (msg.includes('error') || msg.includes('bug') || msg.includes('broken') || msg.includes('not working')) {
        if (code && code.includes('undefined')) {
            return `I see a potential **undefined** reference issue. Check:\n\n1. Make sure all variables are initialized before use\n2. Use optional chaining: \`obj?.property\`\n3. Add a null check: \`if (value !== undefined)\`\n\n\`\`\`javascript\n// Safe pattern:\nconst result = data?.map(item => item.name) ?? [];\n\`\`\``;
        }
        if (code && code.includes('Cannot read properties')) {
            return `This is a classic **TypeError** — you're trying to access a property on \`undefined\` or \`null\`.\n\n**Fix:**\n\`\`\`javascript\n// Add null check before accessing properties\nif (data && Array.isArray(data.posts)) {\n  const mapped = data.posts.map(post => post);\n}\n\`\`\`\n\nCheck your API response matches the shape you expect using \`console.log(data)\`.`;
        }
        return `Let me help debug this. Could you share the **error message** from the console? Also try:\n\n1. Open DevTools → Console for the full stack trace\n2. Add \`console.log\` before the failing line\n3. Check your API returns the expected data shape`;
    }

    // Explanation requests
    if (msg.includes('explain') || msg.includes('what does') || msg.includes('how does')) {
        if (lang === 'javascript' || lang === 'typescript') {
            return `Happy to explain! In JavaScript/TypeScript:\n\n- **Arrow functions** \`() => {}\` are shorthand for function expressions\n- **\`async/await\`** handles Promises more readably than \`.then()\`\n- **Optional chaining** \`obj?.prop\` safely accesses nested properties\n\nWhat specific part would you like me to break down?`;
        }
        if (lang === 'python') {
            return `In Python:\n\n- **List comprehensions** \`[x for x in items]\` are Pythonic loops\n- **f-strings** \`f"Hello {name}"\` are the modern way to format strings\n- **\`with\` statements** ensure resources are cleaned up properly\n\nWhat specific part would you like me to explain?`;
        }
        return `I can explain that! Share the specific code snippet or error you'd like me to break down.`;
    }

    // Optimization requests 
    if (msg.includes('optim') || msg.includes('faster') || msg.includes('performance') || msg.includes('improve')) {
        return `Here are optimization strategies for your code:\n\n**1. Reduce re-renders** (React)\n\`\`\`javascript\nconst memoized = useMemo(() => expensiveCalc(data), [data]);\nconst handler = useCallback(() => doSomething(), [dep]);\n\`\`\`\n\n**2. Avoid blocking operations**\n\`\`\`javascript\n// Use async instead of sync file operations\nawait fs.promises.readFile(path, 'utf8');\n\`\`\`\n\n**3. Use early returns** to reduce nesting and improve readability`;
    }

    // How to questions
    if (msg.includes('how to') || msg.includes('how do i') || msg.includes('how can i')) {
        if (msg.includes('fetch') || msg.includes('api') || msg.includes('request')) {
            return `**Making API requests:**\n\n\`\`\`javascript\n// Modern fetch with error handling\nasync function fetchData(url) {\n  try {\n    const res = await fetch(url);\n    if (!res.ok) throw new Error(\`HTTP \${res.status}\`);\n    return await res.json();\n  } catch (err) {\n    console.error('Fetch failed:', err);\n    throw err;\n  }\n}\n\`\`\`\n\nOr with \`axios\`: \`npm install axios\` → \`const { data } = await axios.get(url)\``;
        }
        if (msg.includes('array') || msg.includes('map') || msg.includes('filter')) {
            return `**Array methods cheat sheet:**\n\n\`\`\`javascript\nconst arr = [1, 2, 3, 4, 5];\n\n// Transform\narr.map(x => x * 2)         // [2, 4, 6, 8, 10]\n\n// Filter\narr.filter(x => x > 2)      // [3, 4, 5]\n\n// Reduce to single value\narr.reduce((sum, x) => sum + x, 0)  // 15\n\n// Find first match\narr.find(x => x > 3)        // 4\n\`\`\``;
        }
    }

    // Greeting
    if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey') || msg === '') {
        return `Hey there! 👋 I'm your AI coding assistant.\n\nI can help you:\n- 🐛 **Debug errors** — paste your error message\n- 📖 **Explain code** — ask what any snippet does\n- ⚡ **Optimize** — review your code for improvements\n- 💡 **Suggest** — best practices for your stack\n\nWhat are you working on?`;
    }

    // Code review
    if (msg.includes('review') || msg.includes('check') || msg.includes('look at')) {
        return `I'll review your code! Here's what I look for:\n\n✅ **Good practices:**\n- Meaningful variable names\n- Error handling with try/catch\n- No magic numbers (use constants)\n- Single responsibility per function\n\n⚠️ **Common issues:**\n- Missing \`await\` before async calls\n- Mutating state directly in React\n- Not handling edge cases (empty arrays, null values)\n\nShare the specific code and I'll give more targeted feedback!`;
    }

    // Default smart response
    const responses = [
        `That's a great question! Based on your ${lang || 'code'}, I'd suggest:\n\n1. Check the browser console for any error messages\n2. Verify all dependencies are installed with \`npm install\`\n3. Look at the network tab to see API responses\n\nCan you share more details about what's not working?`,
        `I see you're working with ${lang || 'code'}. A few things to check:\n\n- Are all imports at the top of the file?\n- Is the data structure what you expect? (log it!)\n- Have you checked for typos in variable names?\n\nPaste the specific error message and I'll help debug it.`,
        `Let me think about that... For ${lang || 'this language'}:\n\n\`\`\`javascript\n// Always log intermediate values when debugging:\nconsole.log('State:', JSON.stringify(yourVariable, null, 2));\n\`\`\`\n\nThis helps see exactly what's happening at each step. What specific behavior are you seeing vs. expecting?`,
    ];
    return responses[Math.floor(Math.random() * responses.length)];
}

// POST /api/ai/chat
router.post('/chat', async (req, res) => {
    const { message, code, language, history } = req.body;

    // Check if real AI API is configured
    const apiKey = process.env.OPENAI_API_KEY || process.env.GEMINI_API_KEY;

    if (apiKey && process.env.OPENAI_API_KEY) {
        // Real OpenAI integration
        try {
            const messages = [
                { role: 'system', content: SYSTEM_CONTEXT },
                ...(history || []).slice(-6), // last 3 exchanges
                {
                    role: 'user',
                    content: code
                        ? `Current file (${language || 'code'}):\n\`\`\`\n${code.slice(0, 2000)}\n\`\`\`\n\nQuestion: ${message}`
                        : message
                }
            ];

            const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${apiKey}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages,
                    max_tokens: 600,
                    temperature: 0.7,
                })
            });
            const data = await openaiRes.json();
            if (data.choices?.[0]?.message?.content) {
                return res.json({ reply: data.choices[0].message.content, model: 'gpt-3.5-turbo' });
            }
        } catch (e) {
            console.error('OpenAI error:', e.message);
        }
    }

    // Fallback: smart mock AI responses
    await new Promise(r => setTimeout(r, 400 + Math.random() * 600)); // simulate latency
    const reply = getMockResponse(message, code, language);
    res.json({ reply, model: 'AI Assistant' });
});

module.exports = router;
