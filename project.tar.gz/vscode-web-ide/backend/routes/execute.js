const express = require('express');
const router = express.Router();
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const WORKSPACE_ROOT = process.env.WORKSPACE_DIR || path.join(__dirname, '..', 'workspace');
const EXECUTION_TIMEOUT = 15000; // 15 seconds

// Language runners
const RUNNERS = {
    javascript: { cmd: 'node', ext: '.js' },
    typescript: { cmd: 'npx', args: ['ts-node'], ext: '.ts' },
    python: { cmd: 'python', ext: '.py', fallbacks: ['python3'] },
    bash: { cmd: 'bash', ext: '.sh' },
    sh: { cmd: 'bash', ext: '.sh' },
};

function detectLanguage(filename, language) {
    if (language && RUNNERS[language]) return language;
    const ext = path.extname(filename || '').toLowerCase();
    const extMap = {
        '.js': 'javascript', '.mjs': 'javascript', '.cjs': 'javascript',
        '.ts': 'typescript',
        '.py': 'python',
        '.sh': 'bash', '.bash': 'bash',
    };
    return extMap[ext] || 'javascript';
}

// POST /api/execute
router.post('/', async (req, res) => {
    const { code, language, filename, filePath } = req.body;

    const lang = detectLanguage(filename || filePath, language);
    const runner = RUNNERS[lang];

    if (!runner) {
        return res.json({ stdout: '', stderr: `Language '${lang}' is not supported yet.`, exitCode: 1, language: lang });
    }

    // Write code to temp file if code is provided inline
    let execPath = filePath ? path.resolve(WORKSPACE_ROOT, filePath.replace(/^\//, '')) : null;
    let tempFile = null;

    if (!execPath || !fs.existsSync(execPath)) {
        // Create temp file
        tempFile = path.join(os.tmpdir(), `vscode-ide-exec-${Date.now()}${runner.ext}`);
        fs.writeFileSync(tempFile, code || '', 'utf8');
        execPath = tempFile;
    }

    const args = [...(runner.args || []), execPath];
    let cmd = runner.cmd;

    return new Promise((resolve) => {
        let stdout = '';
        let stderr = '';
        let timedOut = false;

        const proc = spawn(cmd, args, {
            cwd: WORKSPACE_ROOT,
            env: { ...process.env },
            timeout: EXECUTION_TIMEOUT
        });

        const timer = setTimeout(() => {
            timedOut = true;
            proc.kill('SIGKILL');
        }, EXECUTION_TIMEOUT);

        proc.stdout.on('data', (data) => { stdout += data.toString(); });
        proc.stderr.on('data', (data) => { stderr += data.toString(); });

        proc.on('close', (exitCode) => {
            clearTimeout(timer);
            if (tempFile) {
                try { fs.unlinkSync(tempFile); } catch (e) { /* ignore */ }
            }

            if (timedOut) {
                stderr += '\n[Execution timed out after 15 seconds]';
            }

            res.json({ stdout, stderr, exitCode: timedOut ? -1 : exitCode, language: lang });
            resolve();
        });

        proc.on('error', (err) => {
            clearTimeout(timer);
            if (tempFile) {
                try { fs.unlinkSync(tempFile); } catch (e) { /* ignore */ }
            }

            // Try python3 fallback on Windows
            if (err.code === 'ENOENT' && lang === 'python' && cmd === 'python') {
                const proc2 = spawn('python3', args, { cwd: WORKSPACE_ROOT, env: { ...process.env } });
                let out2 = '', err2 = '';
                proc2.stdout.on('data', d => { out2 += d.toString(); });
                proc2.stderr.on('data', d => { err2 += d.toString(); });
                proc2.on('close', (code) => {
                    res.json({ stdout: out2, stderr: err2, exitCode: code, language: lang });
                    resolve();
                });
                proc2.on('error', (e2) => {
                    res.json({ stdout: '', stderr: `Could not find Python. Install Python and ensure it's in PATH.\n${e2.message}`, exitCode: 1, language: lang });
                    resolve();
                });
            } else {
                res.json({ stdout: '', stderr: `Error starting ${cmd}: ${err.message}`, exitCode: 1, language: lang });
                resolve();
            }
        });
    });
});

module.exports = router;
