const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const WORKSPACE_ROOT = process.env.WORKSPACE_DIR || path.join(__dirname, '..', 'workspace');

// Ensure path is within workspace (security)
function safePath(filePath) {
    const resolved = path.resolve(WORKSPACE_ROOT, filePath.replace(/^\//, ''));
    if (!resolved.startsWith(path.resolve(WORKSPACE_ROOT))) {
        throw new Error('Path traversal detected');
    }
    return resolved;
}

// Build directory tree recursively
function buildTree(dirPath, relativePath = '') {
    const name = path.basename(dirPath);
    const stats = fs.statSync(dirPath);

    if (!stats.isDirectory()) {
        return {
            type: 'file',
            name,
            path: relativePath || name,
            size: stats.size,
            modified: stats.mtime
        };
    }

    let children = [];
    try {
        const items = fs.readdirSync(dirPath);
        children = items
            .filter(item => !item.startsWith('.') && item !== 'node_modules')
            .map(item => buildTree(
                path.join(dirPath, item),
                relativePath ? `${relativePath}/${item}` : item
            ))
            .sort((a, b) => {
                // Folders first, then files
                if (a.type === 'directory' && b.type === 'file') return -1;
                if (a.type === 'file' && b.type === 'directory') return 1;
                return a.name.localeCompare(b.name);
            });
    } catch (e) { /* ignore permission errors */ }

    return {
        type: 'directory',
        name,
        path: relativePath || '.',
        children
    };
}

// GET /api/files/tree - returns directory tree
router.get('/tree', (req, res) => {
    try {
        const tree = buildTree(WORKSPACE_ROOT);
        res.json(tree);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET /api/files/read?path=... - read file content
router.get('/read', (req, res) => {
    try {
        const filePath = safePath(req.query.path || '');
        const content = fs.readFileSync(filePath, 'utf8');
        res.json({ content, path: req.query.path });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST /api/files/write - write file content
router.post('/write', (req, res) => {
    try {
        const { path: filePath, content } = req.body;
        const absPath = safePath(filePath);
        fs.mkdirSync(path.dirname(absPath), { recursive: true });
        fs.writeFileSync(absPath, content, 'utf8');
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST /api/files/create - create file or directory
router.post('/create', (req, res) => {
    try {
        const { path: filePath, type } = req.body; // type: 'file' | 'directory'
        const absPath = safePath(filePath);

        if (type === 'directory') {
            fs.mkdirSync(absPath, { recursive: true });
        } else {
            fs.mkdirSync(path.dirname(absPath), { recursive: true });
            if (!fs.existsSync(absPath)) {
                fs.writeFileSync(absPath, '', 'utf8');
            }
        }
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE /api/files/delete - delete file or directory
router.delete('/delete', (req, res) => {
    try {
        const filePath = safePath(req.query.path || '');
        const stats = fs.statSync(filePath);

        if (stats.isDirectory()) {
            fs.rmSync(filePath, { recursive: true, force: true });
        } else {
            fs.unlinkSync(filePath);
        }
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT /api/files/rename - rename/move file
router.put('/rename', (req, res) => {
    try {
        const { oldPath, newPath } = req.body;
        const absOld = safePath(oldPath);
        const absNew = safePath(newPath);
        fs.renameSync(absOld, absNew);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
